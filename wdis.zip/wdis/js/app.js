// Initialize Wow
new WOW().init();
