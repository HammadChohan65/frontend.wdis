<!-- Header -->
<?php
$title = "Contact US";
$bannerText = "Contact Us";
include 'include/header.php'; ?>

<!-- map -->
<section class="map">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d28946.577045477174!2d67.0914055!3d24.9210938!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb338b808bfd6b1%3A0x997b1a02c2570822!2sGulshan-e-Iqbal%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh!5e0!3m2!1sen!2s!4v1665766842088!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
</section>

<!-- contact us section -->
<section class="contactus">
    <div class="container">
        <div class="row align-items-start justify-content-around">
            <div class="col-12 col-lg-7">
                <div class="contactusForm">
                    <h2 class="mainHeading">Contact Us</h2>
                    <p>Leave us <span>Message</span></p>
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                        <label for="firstname">First Name</label>
                        <input type="text" name="firstname" id="firstname">
                        <label for="email">Email Address</label>
                        <input type="email" name="email" id="email">
                        <label for="phone">Phone</label>
                        <input type="phone" name="phone" id="phone"">
                    <label for=" message">Message</label>
                        <textarea name="message" id="message" cols="30" rows="7"></textarea>
                        <input type="submit" value="send message">
                    </form>
                </div>
            </div>
            <div class="col-12 col-lg-3">
                <div class="callUs">
                    <div class="location">
                    <i class="fa-solid fa-map-location-dot"></i>
                        <h5>our location</h5>
                        <p>lorem7 ipsum situmetstarupstur adipic
                        </p>
                    </div>
                    <div>
                    <i class="fa-solid fa-phone"></i>
                        <h5>call us</h5>
                        <p>+000-000-0000</p>
                    </div>
                    <div>
                    <i class="fa-solid fa-envelope"></i>
                        <h5>email us</h5>
                        <p>example@gmail.com</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<?php include 'include/footer.php';
?>