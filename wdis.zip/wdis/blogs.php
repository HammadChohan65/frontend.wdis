<!-- Header -->
<?php
$title = "Blogs";
$bannerText = "Blogs";
include 'include/header.php'; ?>


<!-- our products section -->
<section class="our-products blog">
    <h1 class="main-heading">our recent blogs</h1>
    <div class="container">

        <div class="row justify-content-between">
            <div class="col-12 col-lg-6">
                <div class="card onlyImage">
                    <a href="#"><img src="images/cards/c17.png" class="imgFluid"></a>
                </div>

            </div>

                <div class="upperDiv">
                    <div class="card">
                        <div>
                            <a href="#" class="date">
                                <span>5 september 20,22 - Recipes</span>
                            </a>
                        </div>
                        <span>
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                        </span>
                        <i class="blog-content-upperDiv">Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit et quasi doloremque at pariatur fugiat ipsum dolor sit amet consectetur adipisicing elit. Suscipit et quasi doloremque r fugiat ipsum dolor sit amet at pariatur fugiat voluptas molestiae?</i>
                        <span class="aero-right-blog">
                            <a href="#">
                                <p><i class="fa-solid fa-arrow-right"></i></p>
                            </a>
                        </span>
                    </div>
                </div>

            <div class="col-12 col-lg-4">
                <div class="card">
                    <a href="#"><img src="images/cards/c16.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="date">
                            <span>5 september 20,22 - Recipes</span>
                        </a>
                    </div>
                    <span>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </span>
                    <span class="aero-right-blog">
                        <a href="#">
                            <p><i class="fa-solid fa-arrow-right"></i></p>
                        </a>
                    </span>
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-12 col-lg-4">
                <div class="card">
                    <a href="#"><img src="images/cards/c16.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="date">
                            <span>5 september 20,22 - Recipes</span>
                        </a>
                    </div>
                    <span>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </span>
                    <span class="aero-right-blog">
                        <a href="#">
                            <p><i class="fa-solid fa-arrow-right"></i></p>
                        </a>
                    </span>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="card">
                    <a href="#"><img src="images/cards/c14.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="date">
                            <span>5 september 20,22 - Recipes</span>
                        </a>
                    </div>
                    <span>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </span>
                    <span class="aero-right-blog">
                        <a href="#">
                            <p><i class="fa-solid fa-arrow-right"></i></p>
                        </a>
                    </span>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="card">
                    <a href="#"><img src="images/cards/c13.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="date">
                            <span>5 september 20,22 - Recipes</span>
                        </a>
                    </div>
                    <span>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </span>
                    <span class="aero-right-blog">
                        <a href="#">
                            <p><i class="fa-solid fa-arrow-right"></i></p>
                        </a>
                    </span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-lg-4">
                <div class="card">
                    <a href="#"><img src="images/cards/c12.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="date">
                            <span>5 september 20,22 - Recipes</span>
                        </a>
                    </div>
                    <span>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </span>
                    <span class="aero-right-blog">
                        <a href="#">
                            <p><i class="fa-solid fa-arrow-right"></i></p>
                        </a>
                    </span>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="card">
                    <a href="#"><img src="images/cards/c11.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="date">
                            <span>5 september 20,22 - Recipes</span>
                        </a>
                    </div>
                    <span>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </span>
                    <span class="aero-right-blog">
                        <a href="#">
                            <p><i class="fa-solid fa-arrow-right"></i></p>
                        </a>
                    </span>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="card">
                    <a href="#"><img src="images/cards/c10.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="date">
                            <span>5 september 20,22 - Recipes</span>
                        </a>
                    </div>
                    <span>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </span>
                    <span class="aero-right-blog">
                        <a href="#">
                            <p><i class="fa-solid fa-arrow-right"></i></p>
                        </a>
                    </span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-lg-4">
                <div class="card">
                    <a href="#"><img src="images/cards/c8.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="date">
                            <span>5 september 20,22 - Recipes</span>
                        </a>
                    </div>
                    <span>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </span>
                    <span class="aero-right-blog">
                        <a href="#">
                            <p><i class="fa-solid fa-arrow-right"></i></p>
                        </a>
                    </span>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="card">
                    <a href="#"><img src="images/cards/c7.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="date">
                            <span>5 september 20,22 - Recipes</span>
                        </a>
                    </div>
                    <span>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </span>
                    <span class="aero-right-blog">
                        <a href="#">
                            <p><i class="fa-solid fa-arrow-right"></i></p>
                        </a>
                    </span>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="card">
                    <a href="#"><img src="images/cards/c6.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="date">
                            <span>5 september 20,22 - Recipes</span>
                        </a>
                    </div>
                    <span>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                    </span>
                    <span class="aero-right-blog">
                        <a href="#">
                            <p><i class="fa-solid fa-arrow-right"></i></p>
                        </a>
                    </span>
                </div>
            </div>
        </div>
    </div>
</section>



<!-- Footer -->
<?php include 'include/footer.php';
?>