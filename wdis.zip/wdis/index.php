<!-- Header -->
<?php
$title="products";$bannerText="Products";
include 'include/header.php'; ?>

<!-- featured cuisines -->
<section class="featured-cuisines">
    <div class="container-fluid">
        <div class="row justify-content-between">
            <div class="col-12">
                <h1 class="main-heading">featured-cuisines</h1>
            </div>
        </div>
        <div class="cardUl">
            <ul>
            <li>
                <div class="card card1">
                    <a href="#"><img src="images/cards/c5.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="money">
                            <span>LOREM ISPUM</span>
                            <span>&dollar;49.49</span>
                        </a>
                    </div>
                    <span>
                        <a href="#">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                        </a>
                    </span>
                </div>
            </li>
            <li>
                <div class="card card2">
                    <a href="#"><img src="images/cards/c3.png" class="imgFluid"></a>
                    <div>
                        <a href="#">
                            <span>LOREM ISPUM</span>
                            <span>&dollar;49.49</span>
                        </a>
                    </div>
                    <span>
                        <a href="#">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                        </a>
                    </span>
                </div>
            </li>

            <li>
                <div class="card card3">
                    <a href="#"><img src="images/cards/c2.png" class="imgFluid"></a>
                    <div>
                        <a href="#">
                            <span>LOREM ISPUM</span>
                            <span>&dollar;49.49</span>
                        </a>
                    </div>
                    <span>
                        <a href="#">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                        </a>
                    </span>
                </div>
            </li>

            <li>
                <div class="card card4">
                    <a href="#"><img src="images/cards/c1.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="money">
                            <span>LOREM ISPUM</span>
                            <span>&dollar;49.49</span>
                        </a>
                    </div>
                    <span>
                        <a href="#">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                        </a>
                    </span>

                </div>
            </li>
            <li>
                <div class="card card5">
                    <a href="#"><img src="images/cards/c4.png" class="imgFluid"></a>
                    <div>
                        <a href="#" class="money">
                            <span>LOREM ISPUM</span>
                            <span>&dollar;49.49</span>
                        </a>
                    </div>
                    <span>
                        <a href="#">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                        </a>
                    </span>
                </div>
            </li>
            </ul>
        </div>
    </div>
    </div>
</section>

<!-- our products section -->
<section class="our-products">
                <h1 class="main-heading">our products</h1>
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-lg-4">
                            <div class="card">
                                <a href="#"><img src="images/cards/c3.png" class="imgFluid"></a>
                                <div>
                                    <a href="#">
                                        <span>LOREM ISPUM</span>
                                        <span>&dollar;49.49</span>
                                    </a>
                                </div>
                                <span>
                                    <a href="#">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </a>
                                </span>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="card">
                                <a href="#"><img src="images/cards/c2.png" class="imgFluid"></a>
                                <div>
                                    <a href="#">
                                        <span>LOREM ISPUM</span>
                                        <span>&dollar;49.49</span>
                                    </a>
                                </div>
                                <span>
                                    <a href="#">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </a>
                                </span>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="card">
                                <a href="#"><img src="images/cards/c1.png" class="imgFluid"></a>
                                <div>
                                    <a href="#" class="money">
                                        <span>LOREM ISPUM</span>
                                        <span>&dollar;49.49</span>
                                    </a>
                                </div>
                                <span>
                                    <a href="#">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </a>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 col-lg-4">
                            <div class="card">
                                <a href="#"><img src="images/cards/c3.png" class="imgFluid"></a>
                                <div>
                                    <a href="#">
                                        <span>LOREM ISPUM</span>
                                        <span>&dollar;49.49</span>
                                    </a>
                                </div>
                                <span>
                                    <a href="#">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </a>
                                </span>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="card">
                                <a href="#"><img src="images/cards/c2.png" class="imgFluid"></a>
                                <div>
                                    <a href="#">
                                        <span>LOREM ISPUM</span>
                                        <span>&dollar;49.49</span>
                                    </a>
                                </div>
                                <span>
                                    <a href="#">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </a>
                                </span>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="card">
                                <a href="#"><img src="images/cards/c1.png" class="imgFluid"></a>
                                <div>
                                    <a href="#" class="money">
                                        <span>LOREM ISPUM</span>
                                        <span>&dollar;49.49</span>
                                    </a>
                                </div>
                                <span>
                                    <a href="#">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </a>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 col-lg-4">
                            <div class="card">
                                <a href="#"><img src="images/cards/c3.png" class="imgFluid"></a>
                                <div>
                                    <a href="#">
                                        <span>LOREM ISPUM</span>
                                        <span>&dollar;49.49</span>
                                    </a>
                                </div>
                                <span>
                                    <a href="#">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </a>
                                </span>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="card">
                                <a href="#"><img src="images/cards/c2.png" class="imgFluid"></a>
                                <div>
                                    <a href="#">
                                        <span>LOREM ISPUM</span>
                                        <span>&dollar;49.49</span>
                                    </a>
                                </div>
                                <span>
                                    <a href="#">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </a>
                                </span>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="card">
                                <a href="#"><img src="images/cards/c1.png" class="imgFluid"></a>
                                <div>
                                    <a href="#" class="money">
                                        <span>LOREM ISPUM</span>
                                        <span>&dollar;49.49</span>
                                    </a>
                                </div>
                                <span>
                                    <a href="#">
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                    </a>
                                </span>
                            </div>
                        </div>
                    </div>
            <div class="row justify-content-center">
            <div class="col-12 col-lg-9">
                <ul class="pagenation">
                    <li><a href=""><i class="fa-solid fa-arrow-left"></i></a></li>
                    <a href="">
                        <li>1</li>
                    </a>
                    <a href="">
                        <li>2</li>
                    </a>
                    <a href="">
                        <li>3</li>
                    </a>
                    <a href="">
                        <li>4</li>
                    </a>
                    <a href="">
                        <li>...</li>
                    </a>
                    <a href="">
                        <li>7</li>
                    </a>
                    <li><a href=""><i class="fa-solid fa-arrow-right"></i></a></li>
                </ul>
            </div>
        </div>
</div>
    </div>
</section>

<!-- features -->
<section class="features">
    <div class="container">
                <div class="row justify-content-center align-items-center">
                    <div class="col-12 col-lg-4">
                        <div class="features-box">
                            <div class="div-img"><img src="images/feature.png" alt="feature"></div>
                            <h3>fresh products</h3>
                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt at ipsa recusandae culpa dolorum!</p>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="features-box">
                            <div class="div-img"><img src="images/feature.png" alt="feature"></div>
                            <h3>fresh products</h3>
                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt at ipsa recusandae culpa dolorum</p>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="features-box">
                            <div class="div-img"><img src="images/feature.png" alt="feature"></div>
                            <h3 class="subHeading">fresh products</h3>
                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt at ipsa recusandae culpa dolorum</p>
                        </div>
                    </div>
                </div>
            </div>
</section>


<!-- Footer -->
<?php include 'include/footer.php'; 
?>