<section class="footer-section">
    <footer>
        <div class="container">
                    <div class="row align-items-start justify-content-center">
                        <div class="col-12 col-lg-4">
                            <div>
                            <h3>LOGO HERE</h3>
                            <p>Lorem ipsum dolor sit amet consect adipisicing elit. Quasi, ad. Eligendi, ther accusamus.</p>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="footer-ul">
                            <ul>
                                <li><h5>Quick Links</h5></li>
                                <a href="">
                                    <li>home</li>
                                </a>
                                <a href="">
                                    <li>about us</li>
                                </a>
                                <a href="">
                                    <li>products</li>
                                </a>
                                <a href="">
                                    <li>blogs</li>
                                </a>
                                <a href="">
                                    <li>contact us</li>
                                </a>
                            </ul>
                            <ul>
                                <li><h5>Follow us</h5></li>
                                <a href="">
                                    <li>facebook</li>
                                </a>
                                <a href="">
                                    <li>twitter</li>
                                </a>
                                <a href="">
                                    <li>instagram</li>
                                </a>
                                <a href="">
                                    <li>linked  in</li>
                                </a>
                            </ul>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="footer-form">
                            <h5>subscribe now</h5>
                            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                                <input type="email" placeholder=" Enter Your Email">
                                <button><i class="fa-solid fa-paper-plane"></i></button>
                            </form>
                            <div class="footer-icons-box">
                                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                                    <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                    <a href="#"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
    </footer>
    <p>&copy;copyright 2022 company name. all right reserved</p>
</section>

</body>
<?php include 'include/js.php'; ?>

</html>