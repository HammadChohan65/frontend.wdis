<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'include/css.php'; ?>
    <title><?php echo isset($title) ? $title : 'Home';  ?></title>
</head>

<body>
    <!-- sub header -->
    <section class="sub-header-section">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-12 col-lg-6">
                    <a href="#">
                        <i class="fa-solid fa-envelope"></i>
                        <span>example@gmail.com</span>
                    </a>
                    <a href="#">
                        <i class="fa-solid fa-phone"></i>
                        <span>+000-000-0000</span>
                    </a>
                </div>
                <div class="col-12 col-lg-6">
                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#"><i class="fa-brands fa-twitter"></i></a>
                    <a href="#"><i><i class="fa-brands fa-google-plus-g"></i></a>
                    <a href="#"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#"><span>|</span></a>
                    <a href="#">
                        <i class="fa-regular fa-user"></i><span>Sign up / Sign In</span>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- navbar -->
    <section class="navbar-section">
        <div class="container">
            <div class="row justify-content-between align-items-center">
                <div class="col-12 col-lg-2">
                    <a href="#" class="logo">LOGO HERE</a>
                </div>
                <div class="col-12 col-lg-9">
                    <ul>
                        <li><a href="index.php">home</a></li>
                        <li><a href="#">about</a></li>
                        <li><a href="productDetails.php">products</a></li>
                        <li><a href="blogs.php">blogs</a></li>
                        <li><a href="contactus.php">contacts</a></li>
                        <li><a href="#" class="mx-5"><i class="fa-solid fa-magnifying-glass"></i></a>
                        <a href="#"><i class="fa-solid fa-cart-shopping"></i></a></li>
                        <li class="nav-have-questions"><a href="#"><i class="fa-solid fa-comments"></i> <span>have questions</span></a></li>

                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- banner -->
    <section class="banner-section wow backInDown" data-wow-duration="2s" style="animation-name:backInDown;animation-duration:2s;">
        <div class="container">
                    <div class="banner-text">
                        <p><?php echo isset($bannerText) ? $bannerText : 'Home';  ?></p>
                    </div>
        </div>
    </section>